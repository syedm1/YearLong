import urllib2, json, sys

data = {'domain': open('domain_blocks.pddl', 'r').read(),
        'problem': open('problem_blocks.pddl', 'r').read()}

req = urllib2.Request('http://solver.planning.domains/solve')
req.add_header('Content-Type', 'application/json')
response=urllib2.urlopen(req, json.dumps(data)).read()
resp = json.loads(response)
print(resp)
with open('result.txt', 'w') as f:
    # f.write('\n'.join([act['name'] for act in resp['result']['plan']]))
    f.write(response)