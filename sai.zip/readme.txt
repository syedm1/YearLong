problem_bloacks.pddl 
domain_blocks.pddl
pddl.py  => Call Api to get the solution json and write in the result.txt
predicates.json =>  The predicates that the colin need for visualistaion
result.txt